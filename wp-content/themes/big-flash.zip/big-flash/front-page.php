<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Big_Flash
 */

get_header();
?>
<div class="site-branding">
			
	<?php if ( get_field( 'hero_image', 'option' ) ) : ?>
		<img src="<?php the_field( 'hero_image', 'option' ); ?>" />
	<?php endif ?>
</div><!-- .site-branding -->
	<div class="image-container">
		<?php if (have_rows('partner_logo', 'option')):
			while(have_rows('partner_logo', 'option')) : the_row();
				$logo_file = get_sub_field('partner_logo_file', 'option');
?>
<img src="<?php echo $logo_file;?>">
				
		<?php endwhile;
	endif;
		?>
	</div>
		
	<?php if (have_rows('main_section')):?>
		
		<main id="primary" class="site-main">
			
			<?php while (have_rows('main_section')): the_row();?>
				
				<?php if (get_row_layout() == 'content_row') :?>
					
					<?php $rows = get_row('content_row');?>
						
						<?php if ($rows['content_block_background_color'] == 1):
						
							$background_color ="#E7ECEF";
						else:
							$background_color="none";
						
						endif?>
					
					<div class="content-block" style="background-color:<?php echo $background_color;?>;">
						
							<?php echo $rows['content_row_content'];?>
					
					</div>

				<?php elseif (get_row_layout() == 'highlight_section'):
					
					$rows = get_row('highlight_section');?>
					
						
						<?php if ($rows['content_block_background_color'] == 1):
							
								$background_color ="#E7ECEF";
							else:
								$background_color="none";
						
						endif?>
						
						<div class="content-block" style="background-color:<?php echo $background_color;?>;">
						<?php if (have_rows('highlight_block_column')):?>
							<ul class="highlight-row">
								<?php while (have_rows('highlight_block_column')) : the_row();
									$highlight_block_item = get_row('highlight_block_column');?>
									<li>
									<img src="<?php echo $highlight_block_item['highlight_block_item_image']?>">
										<h1><?php echo $highlight_block_item['highlight_block_item_title'] ?></h1>
										<p><?php echo $highlight_block_item['highlight_block_item_content']?></p>
										
									</li>
								<?php endwhile;?>
							</ul>
						<?php endif?>
							

						</div>
							
				<?php elseif (get_row_layout() == 'highlight_posts_section'):?>
						
					<?php $rows = get_row('highlight_posts_section');?>
						
						<?php if ($rows['content_block_background_color'] == 1):
								$background_color ="#E7ECEF";
							else:
								$background_color="none";
						endif?>
						
						<div class="content-block" style="background-color:<?php echo $background_color;?>;">
							
							<?php if (have_rows('highlight_posts_column')):?>
								<ul class="highlight-row">
								<?php while (have_rows('highlight_posts_column')): the_row();
									 // set up post object
									$post_object = get_sub_field('highlight_posts_item');
										if( $post_object ) :
											$post = $post_object;
											setup_postdata($post);
								?>
										<li>
											<img src="<?php the_post_thumbnail_url();?>">
											<span class="highlight-item-date"><?php the_date();?></span>
											<br><a href="<?php the_permalink();?>"><?php the_title();?></a>
											<span><?php the_excerpt();?></span>
										</li>
									<?php wp_reset_postdata();
								endif;
							endwhile;?>

								</ul>
							<?php endif;?>		
						</div>
									
				<?php endif?>
							
			<?php endwhile?>
		</main><!-- #main -->	
	<?php endif?>
<?php
//get_sidebar();
get_footer();
