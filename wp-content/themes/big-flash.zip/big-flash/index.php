<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Big_Flash
 */

get_header();
?>



	<main id="primary" class="site-main">
	<?php if ( have_rows( 'content_block' ) ) : ?>
		<div class="content-block"
		<?php if ( the_sub_field( 'content_block_background_color' ) == 1 ) : 
			$background_color = "#E7ECEF"; 
		endif; ?>
			
			
			 style="background-color: <?php echo $background_color; ?>;">
			<?php var_dump(the_sub_field("content_block_background_color"));?>
			<?php while ( have_rows( 'content_block' ) ) : the_row(); ?>
				<div class="content-block-content-wrapper">
					<div class="content-block-content-container">
					
						<?php the_sub_field( 'content_block_content_container' ); ?>
				
					</div>
				</div>
				
				
				
			
			<?php endwhile; ?>
		</div>
		<?php endif; 
		
		if ( have_rows( 'highlight_block' ) ) : 
			while ( have_rows( 'highlight_block' ) ) : the_row(); ?>
			
			<div class="content-block">
				<div class="content-block-content-wrapper">
					<div class="content-block-content-container">
					<?php $highlight_item = get_sub_field( 'highlight_item' ); ?>
						<div class="highlight-item">
						
							<?php if ( $highlight_item ) : 
								
								$post = $highlight_item; 
								
									setup_postdata( $post ); ?> 

										<img src="<?php the_post_thumbnail_url();?>">
										<span><?php the_date(); ?></span>
							
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							
										<span><?php the_excerpt(); ?></span>

									<?php wp_reset_postdata(); ?>
						</div>
						
							<?php endif;?>
					</div>
					
				</div>
			</div>
			<?php endwhile; 
		endif; ?>
		<?php if ( have_rows( 'highlight_block_copy' ) ) : ?>
			<?php while ( have_rows( 'highlight_block_copy' ) ) : the_row(); ?>
				<div class="content-block">
					<div class="content-block-content-wrapper">
						<div class="content-block-content-container">
							<?php if ( get_sub_field( 'highlight_image' ) ) : ?>
								<div class="highlight-item">
									<img src="<?php the_sub_field( 'highlight_image' ); ?>" />
									<?php $highlight_url = get_sub_field( 'highlight_url' ); 
										if ( $highlight_url ) : ?>
											<a href="<?php echo esc_url( $highlight_url); ?>">
											
												<h1><?php the_sub_field( 'highlight_title' ); ?></h1>
											</a>
										<?php endif ?>
												<span><?php the_sub_field( 'highlight_content' ); ?></span>
								</div>
									
						</div>
					</div>
				</div>
				
				<?php endif; ?>
			<?php endwhile; ?>
		<?php endif; ?>
		<?php/*
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) :
				?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>
				<?php
			endif;

			/* Start the Loop */
			/*while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 
				get_template_part( 'template-parts/content', get_post_type() );

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;*/
		?>

	</main><!-- #main -->

<?php
//get_sidebar();
get_footer();
