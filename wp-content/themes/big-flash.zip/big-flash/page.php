<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Big_Flash
 */

get_header();
?>
		<?php if (have_rows('main_section')):?>
			<main id="primary" class="site-main">
				<?php while (have_rows('main_section')): the_row();?>
					
						<?php if (get_row_layout() == 'content_section'):
							$rows = get_sub_field('content_block');?>
							<?php foreach ($rows as $row):?>
								<?php if ($row['content_block_background_color'] == 1) :
									$background_color="#E7ECEF";
								endif;?>
							<div class="content-block" style="background-color:<?php echo $background_color;?>">
								<?php echo $row['content_block_content'];?>
							</div>
							<?php endforeach?>
						<?php elseif (get_row_layout() == 'highlight_section'):
							$columns = get_sub_field('highlight_block_column');?>
								<div class="content-block">
							<?php foreach ($columns as $column):?>
									<div class="highlight-item">
									<img src="<?php echo $column['highlight_block_item_image']?>">
									<h1><?php echo $column['highlight_block_item_title'] ?></h1>
									<p><?php echo $column['highlight_block_item_content']?></p>
								</div>
							<?php endforeach?>
							</div>
						
						<?php elseif (get_row_layout() == 'highlight_posts_section'):?>
							<?php $highlight_posts = get_sub_field('highlight_posts_column');?>
								<div class="content-block">
									<?php foreach ($highlight_posts as $post):
										setup_postdata($post);?>
										<div class="highlight-item">
											
											<img class="highlight-item-img" src="<?php the_post_thumbnail_url();?>">
											<span class="highlight-item-date"><?php the_date();?></span>
											<h1 class="highlight-item-title"><?php the_title();?></h1>
											<span class="highlight-item-content"><?php the_excerpt(); ?></p>

										</div>
									<?php endforeach?>
									<?php wp_reset_postdata();?>
								</div>
									
						<?php endif?>
						
				<?php endwhile?>
				</main><!-- #main -->	
		<?php endif?>
		
<?php
get_footer();
